#!/bin/bash
target_dir=~/.local/share/kservices5/srvrupload
rm -Rf $target_dir